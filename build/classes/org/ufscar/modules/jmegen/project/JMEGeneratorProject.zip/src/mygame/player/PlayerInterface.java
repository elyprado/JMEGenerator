/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.player;

import com.jme3.asset.AssetManager;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;

/**
 *
 * @author ely
 */
public interface PlayerInterface {
    public void buildPlayer(PhysicsSpace physicsSpace, Node rootNode, AssetManager assetManager);
    public void update();
    public void setPhysicsLocation(Vector3f vec);
    public void setPhysicisRotation(Quaternion rot);
    public Node getNode();
    public void turnRight(boolean rightRotate);
    public void turnLeft(boolean leftRotate);
    public void forward(boolean forward);
    public void backward(boolean backward);
    public void action(boolean action);
    public boolean isTurnRight();
    public boolean isTurnLeft();
    public boolean isForward();
    public boolean isBackward();
    public void unbuildPlayer(PhysicsSpace physicsSpace, Node rootNode, AssetManager assetManager);

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.track;

import com.jme3.asset.AssetManager;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.scene.Node;
import java.util.ArrayList;
import mygame.track.parts.Part;

/**
 *
 * @author ely
 */
public interface TrackInterface {
    public void createTrack(AssetManager assetManager, Node rootNode, PhysicsSpace physicsSpace);
    public ArrayList<Part> getParts();
}

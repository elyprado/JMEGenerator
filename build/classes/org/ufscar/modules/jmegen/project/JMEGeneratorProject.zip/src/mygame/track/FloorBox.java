/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.track;

import com.jme3.asset.AssetManager;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.material.Material;
import com.jme3.math.Vector2f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;
import com.jme3.texture.Texture;
import java.util.List;
import mygame.track.parts.Part;

/**
 *
 * @author ely
 */
public class FloorBox {
    public void createFloorBox(AssetManager assetManager, Node rootNode, PhysicsSpace physicsSpace, List<Part> parts) {
        Material material = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        Texture floortexture = assetManager.loadTexture("Interface/grass-texture.jpg");
        floortexture.setWrap(Texture.WrapMode.Repeat);
        material.setTexture("ColorMap",floortexture);
        
        float x1=Float.MAX_VALUE;
        float x2=0;
        float y1=Float.MAX_VALUE;
        float y2=0;
        for (Part part : parts) {
            if (part.getX()<x1) {
                x1 = part.getX();
            }
            if (part.getX()>x2) {
                x2 = part.getX();
            }
            if (part.getZ()<y1) {
                y1 = part.getZ();
            }
            if (part.getZ()>y2) {
                y2 = part.getZ();
            }
        }
        
        
        Box floorBox = new Box(x2-x1+32, 0.25f, y2-y1+32);
        floorBox.scaleTextureCoordinates(new Vector2f(100f, 100f));
        Geometry floorGeometry = new Geometry("Floor", floorBox);
        
        floorGeometry.setMaterial(material);
        floorGeometry.setLocalTranslation(x1, -0.3f, y1);
        floorGeometry.addControl(new RigidBodyControl(0));
        rootNode.attachChild(floorGeometry);
        physicsSpace.add(floorGeometry);
    }

}

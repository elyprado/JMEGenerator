/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.camera;

import com.jme3.input.FlyByCamera;
import com.jme3.renderer.Camera;
import mygame.player.PlayerInterface;

/**
 *
 * @author ely
 */
public interface CameraInterface {
    public void configureCam(PlayerInterface player, FlyByCamera flyCam, Camera cam);
    public void update(PlayerInterface player);
    public void detachCam(PlayerInterface player);
}

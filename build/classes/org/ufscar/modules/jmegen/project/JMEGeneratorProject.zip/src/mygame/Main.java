
package mygame;

import mygame.player.newPlayer;
import mygame.track.newTrack;
import mygame.camera.newCamera;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.light.DirectionalLight;
import com.jme3.math.Vector3f;
import mygame.camera.CameraInterface;
import mygame.player.PlayerInterface;
import mygame.track.StartPositionCalculator;
import mygame.track.TrackInterface;


public class Main extends SimpleApplication implements ActionListener  {

    private BulletAppState bulletAppState;
    
    private PlayerInterface player  = new newPlayer();
    private CameraInterface camera = new newCamera();
    private TrackInterface track = new newTrack();
    
    private Sky sky;
    private StartPositionCalculator startPositionCalculator;
    
    public static void main(String[] args) {
        Main app = new Main();
        app.start();
    }

    private void setupKeys() {
        inputManager.addMapping("Lefts", new KeyTrigger(KeyInput.KEY_LEFT));
        inputManager.addMapping("Rights", new KeyTrigger(KeyInput.KEY_RIGHT));
        inputManager.addMapping("Ups", new KeyTrigger(KeyInput.KEY_UP));
        inputManager.addMapping("Downs", new KeyTrigger(KeyInput.KEY_DOWN));
        inputManager.addMapping("Space", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addMapping("Reset", new KeyTrigger(KeyInput.KEY_RETURN));
        inputManager.addListener(this, "Lefts");
        inputManager.addListener(this, "Rights");
        inputManager.addListener(this, "Ups");
        inputManager.addListener(this, "Downs");
        inputManager.addListener(this, "Space");
        inputManager.addListener(this, "Reset");
    }


    @Override
    public void simpleInitApp() {
        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);

        setupKeys();
        
        //iluminação
        DirectionalLight dl = new DirectionalLight();
        dl.setDirection(new Vector3f(-0.5f, -1f, -0.3f).normalizeLocal());
        rootNode.addLight(dl);

        dl = new DirectionalLight();
        dl.setDirection(new Vector3f(0.5f, -0.1f, 0.3f).normalizeLocal());
        rootNode.addLight(dl);

        
        track.createTrack(assetManager, rootNode, bulletAppState.getPhysicsSpace());
        
        sky = new Sky(assetManager, rootNode);

        player.buildPlayer(getPhysicsSpace(), rootNode, assetManager);
        
        camera.configureCam(player, flyCam, cam);

        startPositionCalculator = new StartPositionCalculator();
        startPositionCalculator.startPosition(player, track);
    }

    private PhysicsSpace getPhysicsSpace() {
        return bulletAppState.getPhysicsSpace();
    }

   
    
    public void onAction(String binding, boolean value, float tpf) {
        if (binding.equals("Lefts")) {
            player.turnLeft(value);
        } else if (binding.equals("Rights")) {
            player.turnRight(value);
        } else if (binding.equals("Ups")) {
            player.forward(value);
        } else if (binding.equals("Downs")) {
            player.backward(value);
        } else if (binding.equals("Space")) {
            player.action(value);
        }
    }

    @Override
    public void simpleUpdate(float tpf) {
    
        player.update();
        
        camera.update(player);
    }
    
}

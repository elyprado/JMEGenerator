/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.track;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import mygame.player.PlayerInterface;
import mygame.track.parts.Part;


/**
 *
 * @author ely
 */
public class StartPositionCalculator {
    public void startPosition(PlayerInterface player, TrackInterface track) {
        
        for (Part part : track.getParts()) {
            if (part.getModel().contains("start1")) {
                player.setPhysicsLocation(new Vector3f(part.getX()+15, 1, part.getZ()+22));
                player.setPhysicisRotation(new Quaternion(0, 1, 0, 0));
                break;
            } else if (part.getModel().contains("start2")) {
                player.setPhysicsLocation(new Vector3f(part.getX()+22, 1, part.getZ()+15));
                player.setPhysicisRotation(new Quaternion(0, 0, 0, 0));
                break;
            } else if (part.getModel().contains("start3")) {
                player.setPhysicsLocation(new Vector3f(part.getX()+22, 1, part.getZ()+22));
                player.setPhysicisRotation(new Quaternion(0.008759044F,-0.6810324F, 0.008030587F, 0.7321569F));
                
                break;
            } else if (part.getModel().contains("start4")) {
                player.setPhysicsLocation(new Vector3f(part.getX()+15, 1, part.getZ()+15));
                player.setPhysicisRotation(new Quaternion(0.008321148F, 0.708795F, -0.0084834965F, 0.7053144F));
                break;
            }
            
        }
        
        
    }
}

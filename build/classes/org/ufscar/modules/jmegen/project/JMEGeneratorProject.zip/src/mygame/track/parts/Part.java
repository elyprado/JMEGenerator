/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.track.parts;

import com.jme3.asset.AssetManager;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author ely
 */
public class Part {
    protected Spatial scene;
    protected RigidBodyControl terrainPhysicsNode;
    private float x;
    private float y;
    private float z;
    private String model;

    public Part(String model, float x, float y, float z){
        this.model = model;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public void createPart(AssetManager assetManager) {
        scene = assetManager.loadModel(model);
        terrainPhysicsNode = new RigidBodyControl(CollisionShapeFactory.createMeshShape(scene), 0);
    }
    
    public void attach(Node rootNode, PhysicsSpace physicsSpace) {
        Vector3f pos = new Vector3f(x, y, z);
        scene.move(pos);
        rootNode.attachChild(scene);
        terrainPhysicsNode.setPhysicsLocation(pos);
        physicsSpace.add(terrainPhysicsNode);
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }
    
    public void setPosition(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    
    
}
